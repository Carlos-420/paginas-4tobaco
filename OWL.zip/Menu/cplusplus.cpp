
#include <iostream>
#include <coino.h>
using namespace std;
class Perro{
	private:
		string raza, nombre;
	public:
		Perro(string, string); //Constructor
		~Perro();//Destructor
		void mostrarDatos();
		void jugar();
};
Perro::Perro(string name, string _raza){
	nombre = name;
	raza= _raza;
}

Perro::~Perro(){
}
void Perro::mostrarDatos(){
	cout<<"Nombre: "<<nombre<<endl;
	cout<<"Raza: "<<raza<<endl;
}
void Perro::jugar(){
	cout<<"El perro "<<nombre<<" esta jugando"<<endl;
}
int main(){
	Perro Perro1("Fido","Doberman");
	Perro1.mostrarDatos();
	Perro1.jugar();
	Perro1.~Perro();//Destruye el objeto
	cout<<"\n";
    cout<<"Si se elimino"<<endl;
}
